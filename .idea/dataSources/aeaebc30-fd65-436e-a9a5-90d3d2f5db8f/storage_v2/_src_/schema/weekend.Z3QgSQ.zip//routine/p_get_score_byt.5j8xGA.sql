create
    definer = root@`%` procedure p_get_score_byt(IN type varchar(10), OUT result_score double(11, 2))
begin
    #判断type如果是avg则给平均分，如果是sum则给总分
    case type
        when 'avg'
            then select avg(score) from result into result_score;
        when 'sum'
            then select sum(score) into result_score  from result;
        when 'min'
            then select min(score) into result_score  from result;
    end case;
end;

