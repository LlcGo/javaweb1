create
    definer = root@`%` function f_get_menory1() returns double(11, 2)
begin
    declare avg_cash double(11,2);
    select avg(cash) from bank into avg_cash;
    return avg_cash;
end;

