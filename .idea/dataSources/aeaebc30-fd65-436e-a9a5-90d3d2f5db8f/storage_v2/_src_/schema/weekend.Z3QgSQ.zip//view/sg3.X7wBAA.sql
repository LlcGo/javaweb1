create view sg3 as
select `sg`.`name` AS `xsm`, `sg`.`gradeName` AS `gradeName`, `s`.`SubjectName` AS `SubjectName`, `r`.`score` AS `fs`
from ((`weekend`.`sg` left join `weekend`.`result` `r` on ((`r`.`studentId` = `sg`.`id`)))
         left join `weekend`.`subject` `s` on ((`r`.`SubjectNo` = `s`.`SubjectNo`)));

-- comment on column sg3.xsm not supported: 学生姓名

-- comment on column sg3.gradeName not supported: 年级名称

-- comment on column sg3.fs not supported: 成绩

