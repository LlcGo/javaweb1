create definer = root@`%` trigger trig_bank_modify
    after update
    on bank
    for each row
    insert into bank_action_history(account_id,account_action_flag,action_money)
 values (new.id,case when NEW.cash - OLD.cash = 0 then 3 else 2 end ,new.cash-OLD.cash);

