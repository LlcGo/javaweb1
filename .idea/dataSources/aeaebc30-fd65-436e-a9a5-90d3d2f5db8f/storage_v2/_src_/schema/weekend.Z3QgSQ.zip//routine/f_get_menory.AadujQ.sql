create
    definer = root@`%` function f_get_menory() returns double(11, 2)
begin
    declare avg_cash double(11,2);
    set avg_cash = 11.24;
    return avg_cash;
end;

