create definer = root@`%` trigger trig_bank_add
    after insert
    on bank
    for each row
    insert into bank_action_history(account_id,account_action_flag,action_money)
        value(new.id,1,new.cash);

