create view sg as
select `s`.`id` AS `id`, `s`.`name` AS `name`, `s`.`gradeId` AS `gradeId`, `g`.`gradeName` AS `gradeName`
from (`weekend`.`student` `s`
         left join `weekend`.`grade` `g` on ((`s`.`gradeId` = `g`.`gradeId`)));

-- comment on column sg.id not supported: 主键

-- comment on column sg.name not supported: 学生姓名

-- comment on column sg.gradeId not supported: 年级编号

-- comment on column sg.gradeName not supported: 年级名称

