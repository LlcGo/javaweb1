create definer = root@`%` trigger result_bank_add
    after insert
    on result
    for each row
    insert into result_action_history(student_id, action_flag, action_score)
        value( new.studentId,1,new.score);

