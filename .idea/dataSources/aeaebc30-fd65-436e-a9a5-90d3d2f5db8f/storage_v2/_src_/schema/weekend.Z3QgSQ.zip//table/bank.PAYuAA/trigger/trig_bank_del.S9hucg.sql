create definer = root@`%` trigger trig_bank_del
    after delete
    on bank
    for each row
    insert into bank_action_history(account_id, account_action_flag, action_money)
     VALUES(OLD.id,4,OLD.cash*-1);

