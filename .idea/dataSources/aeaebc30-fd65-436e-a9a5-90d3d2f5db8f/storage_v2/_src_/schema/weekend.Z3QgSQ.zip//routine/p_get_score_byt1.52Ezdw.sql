create
    definer = root@`%` procedure p_get_score_byt1(IN type varchar(10), OUT result_score double(11, 2))
select case type
      when 'max' then max(score)
      when 'avg' then avg(score)
end into result_score
    from result;

