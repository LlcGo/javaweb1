create definer = root@`%` trigger result_bank_modify
    after update
    on result
    for each row
    insert into result_action_history(student_id,action_flag,action_score)
    values (NEW.studentId,case when NEW.score - OLD.score = 0 then 3 else 2 end ,new.score-OLD.score);

