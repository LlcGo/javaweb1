create view sg2 as
select `sg`.`name` AS `xsm`, `sg`.`gradeName` AS `kcm`, `r`.`score` AS `fs`
from (`weekend`.`sg`
         left join `weekend`.`result` `r` on ((`r`.`studentId` = `sg`.`id`)));

-- comment on column sg2.xsm not supported: 学生姓名

-- comment on column sg2.kcm not supported: 年级名称

-- comment on column sg2.fs not supported: 成绩

